<?php

/* base.html.twig */
class __TwigTemplate_5b20544d98168e0d293fc37f78314a076c7f3d5afbbd34955dca93cd90a7ed73 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b3020fdbfd1b8a28aeacf8890e377127feccaa08be9f4c99fb9bcbb58c4d30e0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b3020fdbfd1b8a28aeacf8890e377127feccaa08be9f4c99fb9bcbb58c4d30e0->enter($__internal_b3020fdbfd1b8a28aeacf8890e377127feccaa08be9f4c99fb9bcbb58c4d30e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_5f7aaa7207aea9c45a00bfe0e8a8f419a522d3634935e3b24b4b88761935da61 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5f7aaa7207aea9c45a00bfe0e8a8f419a522d3634935e3b24b4b88761935da61->enter($__internal_5f7aaa7207aea9c45a00bfe0e8a8f419a522d3634935e3b24b4b88761935da61_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_b3020fdbfd1b8a28aeacf8890e377127feccaa08be9f4c99fb9bcbb58c4d30e0->leave($__internal_b3020fdbfd1b8a28aeacf8890e377127feccaa08be9f4c99fb9bcbb58c4d30e0_prof);

        
        $__internal_5f7aaa7207aea9c45a00bfe0e8a8f419a522d3634935e3b24b4b88761935da61->leave($__internal_5f7aaa7207aea9c45a00bfe0e8a8f419a522d3634935e3b24b4b88761935da61_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_29bdb19d91a77faae2ef757548769138d1e2a0e50fb1bdd08375d7c3f5de8c05 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_29bdb19d91a77faae2ef757548769138d1e2a0e50fb1bdd08375d7c3f5de8c05->enter($__internal_29bdb19d91a77faae2ef757548769138d1e2a0e50fb1bdd08375d7c3f5de8c05_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_ed8b9f5495df6e63a93c127530ada8130c19ea4837818d48c0979af13f8ea2c2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ed8b9f5495df6e63a93c127530ada8130c19ea4837818d48c0979af13f8ea2c2->enter($__internal_ed8b9f5495df6e63a93c127530ada8130c19ea4837818d48c0979af13f8ea2c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_ed8b9f5495df6e63a93c127530ada8130c19ea4837818d48c0979af13f8ea2c2->leave($__internal_ed8b9f5495df6e63a93c127530ada8130c19ea4837818d48c0979af13f8ea2c2_prof);

        
        $__internal_29bdb19d91a77faae2ef757548769138d1e2a0e50fb1bdd08375d7c3f5de8c05->leave($__internal_29bdb19d91a77faae2ef757548769138d1e2a0e50fb1bdd08375d7c3f5de8c05_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_51242331b61ace268ce41abc982f58aba098764eb891081c2548afffe123bd17 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_51242331b61ace268ce41abc982f58aba098764eb891081c2548afffe123bd17->enter($__internal_51242331b61ace268ce41abc982f58aba098764eb891081c2548afffe123bd17_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_e57936e29bc09e8f032a873b2cc138f25c2ae547b561664e1d2b730dc9efbe4b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e57936e29bc09e8f032a873b2cc138f25c2ae547b561664e1d2b730dc9efbe4b->enter($__internal_e57936e29bc09e8f032a873b2cc138f25c2ae547b561664e1d2b730dc9efbe4b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_e57936e29bc09e8f032a873b2cc138f25c2ae547b561664e1d2b730dc9efbe4b->leave($__internal_e57936e29bc09e8f032a873b2cc138f25c2ae547b561664e1d2b730dc9efbe4b_prof);

        
        $__internal_51242331b61ace268ce41abc982f58aba098764eb891081c2548afffe123bd17->leave($__internal_51242331b61ace268ce41abc982f58aba098764eb891081c2548afffe123bd17_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_e4d024df3019c7850f70777d35934b5e6bb25c0d0b75faf14f72989edb7988c9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e4d024df3019c7850f70777d35934b5e6bb25c0d0b75faf14f72989edb7988c9->enter($__internal_e4d024df3019c7850f70777d35934b5e6bb25c0d0b75faf14f72989edb7988c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_d91c0441c9744a5f18752dc25f4406cec28ac70e4afd3191ca69dfbbdcccdf2c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d91c0441c9744a5f18752dc25f4406cec28ac70e4afd3191ca69dfbbdcccdf2c->enter($__internal_d91c0441c9744a5f18752dc25f4406cec28ac70e4afd3191ca69dfbbdcccdf2c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_d91c0441c9744a5f18752dc25f4406cec28ac70e4afd3191ca69dfbbdcccdf2c->leave($__internal_d91c0441c9744a5f18752dc25f4406cec28ac70e4afd3191ca69dfbbdcccdf2c_prof);

        
        $__internal_e4d024df3019c7850f70777d35934b5e6bb25c0d0b75faf14f72989edb7988c9->leave($__internal_e4d024df3019c7850f70777d35934b5e6bb25c0d0b75faf14f72989edb7988c9_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_73c1c6955a2861a8f1ffbd4316addfd65fd7c79f1134930e2d2f6b5ca1c979b7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_73c1c6955a2861a8f1ffbd4316addfd65fd7c79f1134930e2d2f6b5ca1c979b7->enter($__internal_73c1c6955a2861a8f1ffbd4316addfd65fd7c79f1134930e2d2f6b5ca1c979b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_4e01aac40a2cf7be3432624de2078b922563b0531d08ccd663ae694735c7f659 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4e01aac40a2cf7be3432624de2078b922563b0531d08ccd663ae694735c7f659->enter($__internal_4e01aac40a2cf7be3432624de2078b922563b0531d08ccd663ae694735c7f659_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_4e01aac40a2cf7be3432624de2078b922563b0531d08ccd663ae694735c7f659->leave($__internal_4e01aac40a2cf7be3432624de2078b922563b0531d08ccd663ae694735c7f659_prof);

        
        $__internal_73c1c6955a2861a8f1ffbd4316addfd65fd7c79f1134930e2d2f6b5ca1c979b7->leave($__internal_73c1c6955a2861a8f1ffbd4316addfd65fd7c79f1134930e2d2f6b5ca1c979b7_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 11,  100 => 10,  83 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "C:\\xampp\\htdocs\\tentamen\\app\\Resources\\views\\base.html.twig");
    }
}
