<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_c009938afcf06bc67a2938392d54e5cd8b8058fb64a135549e68bbf3c0511645 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c453e895c428910e541993af164655ff587ad3c369b9c71cbf1d0f6c94c8f7e7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c453e895c428910e541993af164655ff587ad3c369b9c71cbf1d0f6c94c8f7e7->enter($__internal_c453e895c428910e541993af164655ff587ad3c369b9c71cbf1d0f6c94c8f7e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_388a1c871ad0a892077cae5a63b0d086cc91e19d174d9b3e1314befb925898ce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_388a1c871ad0a892077cae5a63b0d086cc91e19d174d9b3e1314befb925898ce->enter($__internal_388a1c871ad0a892077cae5a63b0d086cc91e19d174d9b3e1314befb925898ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c453e895c428910e541993af164655ff587ad3c369b9c71cbf1d0f6c94c8f7e7->leave($__internal_c453e895c428910e541993af164655ff587ad3c369b9c71cbf1d0f6c94c8f7e7_prof);

        
        $__internal_388a1c871ad0a892077cae5a63b0d086cc91e19d174d9b3e1314befb925898ce->leave($__internal_388a1c871ad0a892077cae5a63b0d086cc91e19d174d9b3e1314befb925898ce_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_9fd0c3fb5cd9b399067a086ffdbfc56e145ad161fff81a5e78878e57d8912c2d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9fd0c3fb5cd9b399067a086ffdbfc56e145ad161fff81a5e78878e57d8912c2d->enter($__internal_9fd0c3fb5cd9b399067a086ffdbfc56e145ad161fff81a5e78878e57d8912c2d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_29a05e3d1fd435d6ac74cbd7a1c55a3e24059ead9ca14650992f2272a9968eaa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_29a05e3d1fd435d6ac74cbd7a1c55a3e24059ead9ca14650992f2272a9968eaa->enter($__internal_29a05e3d1fd435d6ac74cbd7a1c55a3e24059ead9ca14650992f2272a9968eaa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_29a05e3d1fd435d6ac74cbd7a1c55a3e24059ead9ca14650992f2272a9968eaa->leave($__internal_29a05e3d1fd435d6ac74cbd7a1c55a3e24059ead9ca14650992f2272a9968eaa_prof);

        
        $__internal_9fd0c3fb5cd9b399067a086ffdbfc56e145ad161fff81a5e78878e57d8912c2d->leave($__internal_9fd0c3fb5cd9b399067a086ffdbfc56e145ad161fff81a5e78878e57d8912c2d_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_bff154098076a6eca5876691167c913c1774aab62de68237ccf19d7f240cbff2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bff154098076a6eca5876691167c913c1774aab62de68237ccf19d7f240cbff2->enter($__internal_bff154098076a6eca5876691167c913c1774aab62de68237ccf19d7f240cbff2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_0c56468a0bd01e265d134f89b36ff009850c5e739746c8258dcce935437634d2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0c56468a0bd01e265d134f89b36ff009850c5e739746c8258dcce935437634d2->enter($__internal_0c56468a0bd01e265d134f89b36ff009850c5e739746c8258dcce935437634d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_0c56468a0bd01e265d134f89b36ff009850c5e739746c8258dcce935437634d2->leave($__internal_0c56468a0bd01e265d134f89b36ff009850c5e739746c8258dcce935437634d2_prof);

        
        $__internal_bff154098076a6eca5876691167c913c1774aab62de68237ccf19d7f240cbff2->leave($__internal_bff154098076a6eca5876691167c913c1774aab62de68237ccf19d7f240cbff2_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_fb0a285ac40f2678c293d81670639983631b61140888951ecda49093ed840577 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fb0a285ac40f2678c293d81670639983631b61140888951ecda49093ed840577->enter($__internal_fb0a285ac40f2678c293d81670639983631b61140888951ecda49093ed840577_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_220fa0ae4c2c64ea34f9d5583d0c11cac4441926fc60bb17f96f11befec83750 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_220fa0ae4c2c64ea34f9d5583d0c11cac4441926fc60bb17f96f11befec83750->enter($__internal_220fa0ae4c2c64ea34f9d5583d0c11cac4441926fc60bb17f96f11befec83750_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_220fa0ae4c2c64ea34f9d5583d0c11cac4441926fc60bb17f96f11befec83750->leave($__internal_220fa0ae4c2c64ea34f9d5583d0c11cac4441926fc60bb17f96f11befec83750_prof);

        
        $__internal_fb0a285ac40f2678c293d81670639983631b61140888951ecda49093ed840577->leave($__internal_fb0a285ac40f2678c293d81670639983631b61140888951ecda49093ed840577_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\xampp\\htdocs\\tentamen\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
