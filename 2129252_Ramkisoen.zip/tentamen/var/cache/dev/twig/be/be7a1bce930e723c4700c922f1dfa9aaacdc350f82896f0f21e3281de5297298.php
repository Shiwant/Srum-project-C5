<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_0920480bce2627ecd94a394abf3aaa1f6c65e33cafdf6a6f6aa2a2466968148c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_28019a4ef9ebd37a35176d0399736e2100ce03eb89ceb18203b1b966cbd8250b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_28019a4ef9ebd37a35176d0399736e2100ce03eb89ceb18203b1b966cbd8250b->enter($__internal_28019a4ef9ebd37a35176d0399736e2100ce03eb89ceb18203b1b966cbd8250b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_950b0fcf782cde50f1b0ebe2d3774fbde4b5a7c18dde48d054922cd950330aea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_950b0fcf782cde50f1b0ebe2d3774fbde4b5a7c18dde48d054922cd950330aea->enter($__internal_950b0fcf782cde50f1b0ebe2d3774fbde4b5a7c18dde48d054922cd950330aea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_28019a4ef9ebd37a35176d0399736e2100ce03eb89ceb18203b1b966cbd8250b->leave($__internal_28019a4ef9ebd37a35176d0399736e2100ce03eb89ceb18203b1b966cbd8250b_prof);

        
        $__internal_950b0fcf782cde50f1b0ebe2d3774fbde4b5a7c18dde48d054922cd950330aea->leave($__internal_950b0fcf782cde50f1b0ebe2d3774fbde4b5a7c18dde48d054922cd950330aea_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_8b43c65b1c96c402ae58ce4bdae88d865daf7c6e70510c03773c420b0674a265 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8b43c65b1c96c402ae58ce4bdae88d865daf7c6e70510c03773c420b0674a265->enter($__internal_8b43c65b1c96c402ae58ce4bdae88d865daf7c6e70510c03773c420b0674a265_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_f77720797571bd059271bceec222351416da4dbb6fbe69906ab41bcac548d72c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f77720797571bd059271bceec222351416da4dbb6fbe69906ab41bcac548d72c->enter($__internal_f77720797571bd059271bceec222351416da4dbb6fbe69906ab41bcac548d72c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_f77720797571bd059271bceec222351416da4dbb6fbe69906ab41bcac548d72c->leave($__internal_f77720797571bd059271bceec222351416da4dbb6fbe69906ab41bcac548d72c_prof);

        
        $__internal_8b43c65b1c96c402ae58ce4bdae88d865daf7c6e70510c03773c420b0674a265->leave($__internal_8b43c65b1c96c402ae58ce4bdae88d865daf7c6e70510c03773c420b0674a265_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_2b8d9c7fd454eb7bfe291750983c532c5a3d9d6f8064091989bbca4afd052816 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2b8d9c7fd454eb7bfe291750983c532c5a3d9d6f8064091989bbca4afd052816->enter($__internal_2b8d9c7fd454eb7bfe291750983c532c5a3d9d6f8064091989bbca4afd052816_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_e9fe9d41e9c04255e90da743ea85ff2a0d7ea0b6d116fdf7aa63465109a691c5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e9fe9d41e9c04255e90da743ea85ff2a0d7ea0b6d116fdf7aa63465109a691c5->enter($__internal_e9fe9d41e9c04255e90da743ea85ff2a0d7ea0b6d116fdf7aa63465109a691c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_e9fe9d41e9c04255e90da743ea85ff2a0d7ea0b6d116fdf7aa63465109a691c5->leave($__internal_e9fe9d41e9c04255e90da743ea85ff2a0d7ea0b6d116fdf7aa63465109a691c5_prof);

        
        $__internal_2b8d9c7fd454eb7bfe291750983c532c5a3d9d6f8064091989bbca4afd052816->leave($__internal_2b8d9c7fd454eb7bfe291750983c532c5a3d9d6f8064091989bbca4afd052816_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_e4dfa940f367bd9e4f247be9245b85be47fa6b9f66e3028fd19111d4b7cc94de = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e4dfa940f367bd9e4f247be9245b85be47fa6b9f66e3028fd19111d4b7cc94de->enter($__internal_e4dfa940f367bd9e4f247be9245b85be47fa6b9f66e3028fd19111d4b7cc94de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_7bc598801d0067b4e20d960cdb8e1e8aa1186f71aebb241772b222198689fba7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7bc598801d0067b4e20d960cdb8e1e8aa1186f71aebb241772b222198689fba7->enter($__internal_7bc598801d0067b4e20d960cdb8e1e8aa1186f71aebb241772b222198689fba7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_7bc598801d0067b4e20d960cdb8e1e8aa1186f71aebb241772b222198689fba7->leave($__internal_7bc598801d0067b4e20d960cdb8e1e8aa1186f71aebb241772b222198689fba7_prof);

        
        $__internal_e4dfa940f367bd9e4f247be9245b85be47fa6b9f66e3028fd19111d4b7cc94de->leave($__internal_e4dfa940f367bd9e4f247be9245b85be47fa6b9f66e3028fd19111d4b7cc94de_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\xampp\\htdocs\\tentamen\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
